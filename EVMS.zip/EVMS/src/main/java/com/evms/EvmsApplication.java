package com.evms;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EvmsApplication {

	public static void main(String[] args) {
		SpringApplication.run(EvmsApplication.class, args);
	}

}
